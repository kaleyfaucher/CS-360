package com.example.weight_trackingapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

data class WeightEntry(
    val id: Long,
    val value: Double,
    val date: String
)

class WeightRepo(context: Context) {
    private val dbHelper = DBHelper(context)

    fun getAllWeights(): List<WeightEntry> {
        val db: SQLiteDatabase = dbHelper.readableDatabase
        val list = mutableListOf<WeightEntry>()

        val cursor: Cursor = db.query(
            DBHelper.TABLE_WEIGHTS,
            arrayOf(DBHelper.COL_WEIGHT_ID, DBHelper.COL_WEIGHT_VALUE, DBHelper.COL_WEIGHT_DATE),
            null,
            null,
            null,
            null,
            "${DBHelper.COL_WEIGHT_DATE} DESC"
        )

        cursor.use {
            val idIdx = it.getColumnIndexOrThrow(DBHelper.COL_WEIGHT_ID)
            val valueIdx = it.getColumnIndexOrThrow(DBHelper.COL_WEIGHT_VALUE)
            val dateIdx = it.getColumnIndexOrThrow(DBHelper.COL_WEIGHT_DATE)

            while (it.moveToNext()) {
                list.add(
                    WeightEntry(
                        id = it.getLong(idIdx),
                        value = it.getDouble(valueIdx),
                        date = it.getString(dateIdx)
                    )
                )
            }
        }

        return list
    }

    fun insertWeight(value: Double, date: String): Long {
        val db = dbHelper.writableDatabase
        val cv = ContentValues().apply {
            put(DBHelper.COL_WEIGHT_VALUE, value)
            put(DBHelper.COL_WEIGHT_DATE, date)
        }
        return db.insert(DBHelper.TABLE_WEIGHTS, null, cv)
    }

    fun updateWeight(id: Long, value: Double, date: String): Int {
        val db = dbHelper.writableDatabase
        val cv = ContentValues().apply {
            put(DBHelper.COL_WEIGHT_VALUE, value)
            put(DBHelper.COL_WEIGHT_DATE, date)
        }
        return db.update(
            DBHelper.TABLE_WEIGHTS,
            cv,
            "${DBHelper.COL_WEIGHT_ID}=?",
            arrayOf(id.toString())
        )
    }

    fun deleteWeight(id: Long): Int {
        val db = dbHelper.writableDatabase
        return db.delete(
            DBHelper.TABLE_WEIGHTS,
            "${DBHelper.COL_WEIGHT_ID}=?",
            arrayOf(id.toString())
        )
    }
}

