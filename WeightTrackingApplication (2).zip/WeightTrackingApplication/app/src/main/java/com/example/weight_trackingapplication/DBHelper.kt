package com.example.weight_trackingapplication

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "weight_tracker.db"
        const val DATABASE_VERSION = 1

        // Users table
        const val TABLE_USERS = "users"
        const val COL_USER_ID = "user_id"
        const val COL_USERNAME = "username"
        const val COL_PASSWORD = "password"

        // Weights table
        const val TABLE_WEIGHTS = "weights"
        const val COL_WEIGHT_ID = "weight_id"
        const val COL_WEIGHT_VALUE = "weight_value"
        const val COL_WEIGHT_DATE = "weight_date"
    }

    override fun onCreate(db: SQLiteDatabase) {

        val createUsersTable = """
            CREATE TABLE $TABLE_USERS (
                $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USERNAME TEXT UNIQUE,
                $COL_PASSWORD TEXT
            )
        """.trimIndent()

        val createWeightsTable = """
            CREATE TABLE $TABLE_WEIGHTS (
                $COL_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_WEIGHT_VALUE REAL,
                $COL_WEIGHT_DATE TEXT
            )
        """.trimIndent()

        db.execSQL(createUsersTable)
        db.execSQL(createWeightsTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHTS")
        onCreate(db)
    }
}


