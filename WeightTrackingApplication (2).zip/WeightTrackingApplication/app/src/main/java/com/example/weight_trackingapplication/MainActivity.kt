package com.example.weight_trackingapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.weight_trackingapplication.ui.theme.WeightTrackingApplicationTheme

enum class AppScreen {
    LOGIN,
    DATA_GRID,
    SMS_PERMISSION
}

class MainActivity : ComponentActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dbHelper = DBHelper(this)

        setContent {
            WeightTrackingApplicationTheme {
                WeightTrackingApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeightTrackingApp() {
    var currentScreen by remember { mutableStateOf(AppScreen.LOGIN) }

    val context = LocalContext.current
    val userRepo = remember { UserRepo(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Weight Tracking Application") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = { currentScreen = AppScreen.LOGIN }) {
                    Text("Login")
                }
                Button(onClick = { currentScreen = AppScreen.DATA_GRID }) {
                    Text("Data Grid")
                }
                Button(onClick = { currentScreen = AppScreen.SMS_PERMISSION }) {
                    Text("SMS")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (currentScreen) {
                AppScreen.LOGIN -> LoginScreen(userRepo)
                AppScreen.DATA_GRID -> DataGridScreen()
                AppScreen.SMS_PERMISSION -> SmsPermissionScreen()
            }
        }
    }
}

/* ----------------------- LOGIN SCREEN ----------------------- */

@Composable
fun LoginScreen(userRepo: UserRepo) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "User Login",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                message =
                    if (userRepo.validateLogin(username, password)) "Login successful ✅"
                    else "Login failed ❌"
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Log In")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                message =
                    if (userRepo.createUser(username, password)) "Account created ✅"
                    else "User already exists ❌"
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Create Account")
        }

        if (message.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = message)
        }
    }
}
/* ----------------------- SMS PERMISSION SCREEN ----------------------- */

@Composable
fun SmsPermissionScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var statusMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "SMS Notifications",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "SMS alerts are optional. You may allow or deny permission.",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                statusMessage = "Tap Allow or Deny on the system prompt"
            }
        ) {
            Text("Request SMS Permission")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (statusMessage.isNotEmpty()) {
            Text(text = statusMessage)
        }
    }
}

