package com.example.weight_trackingapplication

import android.content.ContentValues
import android.content.Context

class UserRepo(context: Context) {

    private val dbHelper = DBHelper(context)

    fun validateLogin(username: String, password: String): Boolean {
        if (username.isBlank() || password.isBlank()) return false

        val db = dbHelper.readableDatabase
        val cursor = db.query(
            DBHelper.TABLE_USERS,
            arrayOf(DBHelper.COL_USER_ID),
            "${DBHelper.COL_USERNAME} = ? AND ${DBHelper.COL_PASSWORD} = ?",
            arrayOf(username.trim(), password),
            null,
            null,
            null
        )

        val ok = cursor.moveToFirst()
        cursor.close()
        db.close()
        return ok
    }

    fun createUser(username: String, password: String): Boolean {
        if (username.isBlank() || password.isBlank()) return false

        // prevent duplicates
        if (userExists(username.trim())) return false

        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DBHelper.COL_USERNAME, username.trim())
            put(DBHelper.COL_PASSWORD, password)
        }

        val result = db.insert(DBHelper.TABLE_USERS, null, values)
        db.close()
        return result != -1L
    }

    private fun userExists(username: String): Boolean {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            DBHelper.TABLE_USERS,
            arrayOf(DBHelper.COL_USER_ID),
            "${DBHelper.COL_USERNAME} = ?",
            arrayOf(username),
            null,
            null,
            null
        )

        val exists = cursor.moveToFirst()
        cursor.close()
        db.close()
        return exists
    }
}

