package com.example.weight_trackingapplication

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun DataGridScreen() {
    val context = LocalContext.current
    val weightRepo = remember { WeightRepo(context) }

    var weightText by remember { mutableStateOf("") }
    var dateText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }

    var selectedId by remember { mutableStateOf<Long?>(null) }
    var entries by remember { mutableStateOf(listOf<WeightEntry>()) }

    fun refresh() {
        entries = weightRepo.getAllWeights()
    }

    LaunchedEffect(Unit) { refresh() }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Weight History", style = MaterialTheme.typography.headlineSmall)

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = weightText,
            onValueChange = { weightText = it },
            label = { Text("Weight (e.g., 155.6)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = dateText,
            onValueChange = { dateText = it },
            label = { Text("Date (e.g., 2025-12-14)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val w = weightText.toDoubleOrNull()
                    if (w == null || dateText.isBlank()) {
                        status = "Enter a valid weight + date."
                        return@Button
                    }
                    weightRepo.insertWeight(w, dateText.trim())
                    status = "Saved ✅"
                    weightText = ""
                    dateText = ""
                    selectedId = null
                    refresh()
                },
                modifier = Modifier.weight(1f)
            ) { Text("Add") }

            Button(
                onClick = {
                    val id = selectedId
                    val w = weightText.toDoubleOrNull()
                    if (id == null || w == null || dateText.isBlank()) {
                        status = "Select an entry + enter valid values to update."
                        return@Button
                    }
                    weightRepo.updateWeight(id, w, dateText.trim())
                    status = "Updated ✅"
                    weightText = ""
                    dateText = ""
                    selectedId = null
                    refresh()
                },
                modifier = Modifier.weight(1f)
            ) { Text("Update") }

            Button(
                onClick = {
                    val id = selectedId
                    if (id == null) {
                        status = "Select an entry to delete."
                        return@Button
                    }
                    weightRepo.deleteWeight(id)
                    status = "Deleted ✅"
                    weightText = ""
                    dateText = ""
                    selectedId = null
                    refresh()
                },
                modifier = Modifier.weight(1f)
            ) { Text("Delete") }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(status)
        }

        Spacer(Modifier.height(16.dp))

        Divider()
        Spacer(Modifier.height(8.dp))

        // This is your "grid/list" display
        LazyColumn {
            items(entries) { entry ->
                val isSelected = entry.id == selectedId
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable {
                            selectedId = entry.id
                            weightText = entry.value.toString()
                            dateText = entry.date
                            status = "Selected ID: ${entry.id}"
                        },
                    colors = if (isSelected) CardDefaults.cardColors() else CardDefaults.cardColors()
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Date: ${entry.date}")
                        Text("Weight: ${entry.value}")
                        Text("ID: ${entry.id}")
                    }
                }
            }
        }
    }
}
